(define-package "flycheck" "0.25.1" "On-the-fly syntax checking"
  '((dash "2.12.1")
    (pkg-info "0.4")
    (let-alist "1.0.4")
    (cl-lib "0.5")
    (seq "1.11")
    (emacs "24.3"))
  :url "https://www.flycheck.org" :keywords
  '("convenience" "languages" "tools"))
;; Local Variables:
;; no-byte-compile: t
;; End:
